<script setup>
    import Home from '../components/Home.vue'
</script>

<template>
    <Home />
</template>