<script setup>
import Login from '../components/Login.vue'
</script>

<template>
  <main>
    <Login />
  </main>
</template>
