<script setup>
    import Register from '../components/Register.vue'; 
</script>

<template>
    <main><Register /></main>
</template>
